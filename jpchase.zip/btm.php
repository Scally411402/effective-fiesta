<?php
include('Update/autob/bt.php');
include('Update/autob/basicbot.php');
include('Update/autob/uacrawler.php');
include('Update/autob/refspam.php');
include('Update/autob/ipselect.php');
include('Update/autob/bts2.php');
?>
